$(document).ready(function() {

    $('.blockpanelbutton').click(function(){
        if ($('#blockslider').hasClass('show')) {
            window.scrollTo(0, 0);
        }
    });

});
